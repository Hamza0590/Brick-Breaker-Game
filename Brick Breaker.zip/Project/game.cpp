//============================================================================
// Name        : .cpp
// Author      : Sibt ul Hussain
// Version     :
// Copyright   : (c) Reserved
// Description : Basic 2D game of Centipede...
//============================================================================

#ifndef CENTIPEDE_CPP_
#define CENTIPEDE_CPP_
#include"ClassCaller.h"
#include "util.h"
#include <iostream>
#include<string>
#include<ctime>
#include<cmath> // for basic math functions such as cos, sin, sqrt
using namespace std;

ClassCaller c1;
// seed the random numbers generator by current time (see the documentation of srand for further help)...

/* Function sets canvas size (drawing area) in pixels...
 *  that is what dimensions (x and y) your game will have
 *  Note that the bottom-left coordinate has value (0,0) and top-right coordinate has value (width-1,height-1)
 * */
void SetCanvasSize(int width, int height) {
	glMatrixMode (GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0, width, 0, height, -1, 1); // set the screen size to given width and height.
	glMatrixMode (GL_MODELVIEW);
	glLoadIdentity();
}


/*
 * Main Canvas drawing function.
 * */
void MouseMoved(int x, int y)
{
	Powers temp;
	temp = c1.getPower1();
	if ((x>temp.getPaddleChange()/2) && x<(900-temp.getPaddleChange()/2))
	c1.set_mouse_x(x);
	//cout << x << " " << y << endl;
	glutPostRedisplay();
}

void GameDisplay()/**/
{
	Paddle m1;
	m1=c1.returnPaddle();
	Ball b1;
	b1=c1.returnBall();
	c1.setHighestScore();
	Brick **brick = c1.returnBrickArray();

	if(c1.getLives()>0)
	{	

		string highestScore=to_string(c1.getHighestScore());
		string score=to_string(c1.getScore());
		string lives =  to_string(c1.getLives());
		Powers temp = c1.getPower1();

	glClearColor(0, 0,0.0, 0); // Red==Green==Blue==1 --> White Colour
	glClear (GL_COLOR_BUFFER_BIT); //Update the colors
	
	DrawLine( 0 , 740 ,  1024 , 740 , 5 , colors[MISTY_ROSE] ); 		//Upper Portion
	DrawString( 140, 800, "Hamza- 23i0090", colors[MISTY_ROSE]); 				//Upper Portion
	DrawString( 740, 800, "HIGHEST SCORE= "+highestScore, colors[RED]); //Upper Portion
	DrawString( 600, 800, "Score = "+score, colors[DARK_GREEN]); 		//Upper Portion
	DrawString( 400, 800, "lives = "+lives, colors[BLUE]); //Upper Portion
	

	c1.checkLevel();


	if (c1.getPowerCheck()==1) //Drawing Powers Shape
	{
		if(temp.getPowerColor() == 1)
		{
			DrawCircle(temp.getPowerX() , temp.getPowerY(),10,colors[BLUE]);
		}
		else if(temp.getPowerColor() == 2)
		{
			DrawSquare( temp.getPowerX() , temp.getPowerY() , 30 , colors[YELLOW]);
		}
		else if (temp.getPowerColor()==3)
		{
			DrawSquare( temp.getPowerX() , temp.getPowerY() , 30 , colors[DEEP_PINK]);
		}
		else if (temp.getPowerColor()==4)
		{
			DrawTriangle( temp.getPowerX(), temp.getPowerY() , temp.getPowerX()+40, temp.getPowerY() , temp.getPowerX()+20 , temp.getPowerY()+40, colors[DARK_GREEN] );
		}
		else if (temp.getPowerColor()==5)
		{
			DrawRoundRect(temp.getPowerX(), temp.getPowerY() ,20,10,colors[RED],0);
		}
	}

	if(temp.getTimer()>40)
	{
		//Timer

		c1.setStartTimer();
		c1.setTimer(0.001);
	}

	if(c1.getBall2Check()==1)
	{
			//printing Balls

		Ball b2 = c1.getBall2();

		if (c1.getBallColor()==1)
		{
			DrawCircle(b1.get_ballx() , b1.get_bally(),5,colors[BLUE]);
			DrawCircle(b2.get_ballx() , b2.get_bally(),5,colors[BLUE]);
		}
		else if(c1.getBallColor() ==2)
		{
			DrawCircle(b1.get_ballx() , b1.get_bally(),5,colors[YELLOW]);
			DrawCircle(b2.get_ballx() , b2.get_bally(),5,colors[YELLOW]);
		}
		else if(c1.getBallColor() ==3)
		{
			DrawCircle(b1.get_ballx() , b1.get_bally(),5,colors[DEEP_PINK]);
			DrawCircle(b2.get_ballx() , b2.get_bally(),5,colors[DEEP_PINK]);
		}
		else if(c1.getBallColor() ==4)
		{
			DrawCircle(b1.get_ballx() , b1.get_bally(),5,colors[DARK_GREEN]);
			DrawCircle(b2.get_ballx() , b2.get_bally(),5,colors[DARK_GREEN]);
		}
		else if(c1.getBallColor() ==5)
		{
			DrawCircle(b1.get_ballx() , b1.get_bally(),5,colors[RED]);
			DrawCircle(b2.get_ballx() , b2.get_bally(),5,colors[RED]);
		}
	}
	else
	{
		if (c1.getBallColor()==1)
				DrawCircle(b1.get_ballx() , b1.get_bally(),5,colors[BLUE]);
			else if(c1.getBallColor() ==2)
				DrawCircle(b1.get_ballx() , b1.get_bally(),5,colors[YELLOW]);
			else if(c1.getBallColor() ==3)
				DrawCircle(b1.get_ballx() , b1.get_bally(),5,colors[DEEP_PINK]);
			else if(c1.getBallColor() ==4)
				DrawCircle(b1.get_ballx() , b1.get_bally(),5,colors[DARK_GREEN]);
			else if(c1.getBallColor() ==5)
				DrawCircle(b1.get_ballx() , b1.get_bally(),5,colors[RED]);
	}
	if (c1.getPaddle2Check()==1)
	{
		Paddle p2 = c1.getPaddle2();
		{
			//Lower Paddle
			if (c1.getPaddle1Color()== 1)
				DrawRoundRect(m1.getPaddleX()-(temp.getPaddleChange()/2), m1.getPaddleY() ,100+temp.getPaddleChange(),20,colors[BLUE],10);
			else if (c1.getPaddle1Color()== 2)
				DrawRoundRect(m1.getPaddleX()-(temp.getPaddleChange()/2), m1.getPaddleY() ,100+temp.getPaddleChange(),20,colors[YELLOW],10);
			else if (c1.getPaddle1Color()== 3)
				DrawRoundRect(m1.getPaddleX()-(temp.getPaddleChange()/2), m1.getPaddleY() ,100+temp.getPaddleChange(),20,colors[DEEP_PINK],10);
			else if (c1.getPaddle1Color()== 4)
				DrawRoundRect(m1.getPaddleX() -(temp.getPaddleChange()/2), m1.getPaddleY() ,100+temp.getPaddleChange(),20,colors[DARK_GREEN],10);
			else if (c1.getPaddle1Color()== 5)
				DrawRoundRect(m1.getPaddleX() -(temp.getPaddleChange()/2), m1.getPaddleY() ,100+temp.getPaddleChange(),20,colors[RED],10);
			else
				DrawRoundRect(m1.getPaddleX() , m1.getPaddleY() ,100,20,colors[MISTY_ROSE],10);
		}
		{// Upper Paddle
			if (c1.getPaddle2Color()== 1)
				DrawRoundRect(p2.getPaddleX()-(temp.getPaddleChange()/2), p2.getPaddleY() ,100+temp.getPaddleChange(),20,colors[BLUE],10);
			else if (c1.getPaddle2Color()== 2)
				DrawRoundRect(p2.getPaddleX()-(temp.getPaddleChange()/2), p2.getPaddleY() ,100+temp.getPaddleChange(),20,colors[YELLOW],10);
			else if (c1.getPaddle2Color()== 3)
				DrawRoundRect(p2.getPaddleX()-(temp.getPaddleChange()/2), p2.getPaddleY() ,100+temp.getPaddleChange(),20,colors[DEEP_PINK],10);
			else if (c1.getPaddle2Color()== 4)
				DrawRoundRect(p2.getPaddleX() -(temp.getPaddleChange()/2), p2.getPaddleY() ,100+temp.getPaddleChange(),20,colors[DARK_GREEN],10);
			else if (c1.getPaddle2Color()== 5)
				DrawRoundRect(p2.getPaddleX() -(temp.getPaddleChange()/2), p2.getPaddleY() ,100+temp.getPaddleChange(),20,colors[RED],10);
			else
				DrawRoundRect(p2.getPaddleX() , p2.getPaddleY() ,100,20,colors[MISTY_ROSE],10);

		}
	}
	else
	{
		//Lower Paddle
		if (c1.getPaddle1Color()== 1)
				DrawRoundRect(m1.getPaddleX()-(temp.getPaddleChange()/2), m1.getPaddleY() ,100+temp.getPaddleChange(),20,colors[BLUE],10);
			else if (c1.getPaddle1Color()== 2)
				DrawRoundRect(m1.getPaddleX()-(temp.getPaddleChange()/2), m1.getPaddleY() ,100+temp.getPaddleChange(),20,colors[YELLOW],10);
			else if (c1.getPaddle1Color()== 3)
				DrawRoundRect(m1.getPaddleX()-(temp.getPaddleChange()/2), m1.getPaddleY() ,100+temp.getPaddleChange(),20,colors[DEEP_PINK],10);
			else if (c1.getPaddle1Color()== 4)
				DrawRoundRect(m1.getPaddleX() -(temp.getPaddleChange()/2), m1.getPaddleY() ,100+temp.getPaddleChange(),20,colors[DARK_GREEN],10);
			else if (c1.getPaddle1Color()== 5)
				DrawRoundRect(m1.getPaddleX() -(temp.getPaddleChange()/2), m1.getPaddleY() ,100+temp.getPaddleChange(),20,colors[RED],10);
			else
				DrawRoundRect(m1.getPaddleX() , m1.getPaddleY() ,100,20,colors[MISTY_ROSE],10);
	}

//	DrawRoundRect(500,200,50,100,colors[DARK_SEA_GREEN],70);
	
	for (int i =0 ; i<6 ; i++)
			{
				for (int j =0 ; j<10 ; j++)
				{
					if(brick[i][j].getColor()==1)
					{
						DrawRoundRect(brick[i][j].getBrickX() , brick[i][j].getBrickY() , brick[i][j].getLength(), brick[i][j].getWidth() , colors[BLUE],0);
					}
					else if (brick[i][j].getColor()==2)
					{
						DrawRoundRect(brick[i][j].getBrickX() , brick[i][j].getBrickY() , brick[i][j].getLength(), brick[i][j].getWidth() ,colors[YELLOW],0);
					}
					else if (brick[i][j].getColor()==3)
					{
						DrawRoundRect(brick[i][j].getBrickX() , brick[i][j].getBrickY() , brick[i][j].getLength(), brick[i][j].getWidth() ,colors[DEEP_PINK],0);
					}
					else if (brick[i][j].getColor()==4)
					{
						DrawRoundRect(brick[i][j].getBrickX() , brick[i][j].getBrickY() , brick[i][j].getLength(), brick[i][j].getWidth() ,colors[DARK_GREEN],0);
					}
					else if (brick[i][j].getColor()==5)
					{
						DrawRoundRect(brick[i][j].getBrickX() , brick[i][j].getBrickY() , brick[i][j].getLength(), brick[i][j].getWidth() ,colors[RED],0);
					}
					//DrawRoundRect( brick[index].getX(),brick[index].getY() ,brick[index].getLength(),brick[index].getWidth() ,colors[color],0);

				}
			}


	//DrawRoundRect(0 ,700 ,100,25,colors[MISTY_ROSE],0);
	//DrawRoundRect(101 ,700 ,100,25,colors[MISTY_ROSE],0);
	//DrawRoundRect(202 ,700 ,100,25,colors[MISTY_ROSE],0);
	//DrawRoundRect(303 ,812 ,100,25,colors[MISTY_ROSE],0);
	//DrawRoundRect(303 ,786 ,100,25,colors[MISTY_ROSE],0);
	//DrawRoundRect(404 ,700 ,100,25,colors[MISTY_ROSE],0);
	//DrawRoundRect(505 ,700 ,100,25,colors[MISTY_ROSE],0);
	//DrawRoundRect(606 ,700 ,100,25,colors[MISTY_ROSE],0);
	//DrawRoundRect(707 ,700 ,100,25,colors[MISTY_ROSE],0);
	//DrawRoundRect(808 ,700 ,100,25,colors[MISTY_ROSE],0);
	//DrawRoundRect(909 ,700 ,105,25,colors[MISTY_ROSE],0);
	//DrawRoundRect(100, 0 ,100, 25 , colors[BLUE],0);
	//DrawRoundRect(m1.getPaddleX() , m1.getPaddleY() ,150,20,colors[MISTY_ROSE],10);
	//DrawRoundRect(100,100,50,100,colors[DARK_OLIVE_GREEN],30);
	//DrawRoundRect(m1.get_x() , m1.get_y(),100,50,colors[LIME_GREEN],40);
	//DrawRoundRect(350,100,100,50,colors[LIME_GREEN],20);
	
	glutSwapBuffers(); // do not modify this line..}
	
	}
	else if(c1.getLevel()==4 || c1.getLives()==0)
	{

		glClearColor(0/*Red Component*/, 0,	//148.0/255/*Green Component*/,
		0.0/*Blue Component*/, 0 /*Alpha component*/); // Red==Green==Blue==1 --> White Colour
		glClear (GL_COLOR_BUFFER_BIT); //Update the colors
		DrawString( 430, 440, "Game Ended.", colors[MISTY_ROSE]);
		//DrawTriangle( 300, 450 , 340, 450 , 320 , 490, colors[MISTY_ROSE] );
		glutSwapBuffers(); 
		//glutPostRedisplay();
	}

}

/*This function is called (automatically) whenever any non-printable key (such as up-arrow, down-arraw)
 * is pressed from the keyboard
 *
 * You will have to add the necessary code here when the arrow keys are pressed or any other key is pressed...
 *
 * This function has three argument variable key contains the ASCII of the key pressed, while x and y tells the
 * program coordinates of mouse pointer when key was pressed.
 *
 * */

void NonPrintableKeys(int key, int x, int y) {
	if (key== GLUT_KEY_LEFT /*GLUT_KEY_LEFT is constant and contains ASCII for left arrow key*/) {
		// what to do when left key is pressed...

		c1.setPaddle2XCordinate(-30);

		

	} else if (key== GLUT_KEY_RIGHT /*GLUT_KEY_RIGHT is constant and contains ASCII for right arrow key*/) {
		c1.setPaddle2XCordinate(30);

	} else if (key
			== GLUT_KEY_UP/*GLUT_KEY_UP is constant and contains ASCII for up arrow key*/) {

	}

	else if (key
			== GLUT_KEY_DOWN/*GLUT_KEY_DOWN is constant and contains ASCII for down arrow key*/) {

	}

	/* This function calls the Display function to redo the drawing. Whenever you need to redraw just call
	 * this function*/

	glutPostRedisplay();

}

/*This function is called (automatically) whenever any printable key (such as x,b, enter, etc.)
 * is pressed from the keyboard
 * This function has three argument variable key contains the ASCII of the key pressed, while x and y tells the
 * program coordinates of mouse pointer when key was pressed.
 * */
void PrintableKeys(unsigned char key, int x, int y) {
	if (key == 27/* Escape key ASCII*/) {
		exit(1); // exit the program when escape key is pressed.
	}

	if (key == 'b' || key == 'B') //Key for placing the bomb
			{
		//do something if b is pressed
		cout << "b pressed" << endl;

	}
	glutPostRedisplay();
}

/*
 * This function is called after every 1000.0/FPS milliseconds
 * (FPS is defined on in the beginning).
 * You can use this function to animate objects and control the
 * speed of different moving objects by varying the constant FPS.
 *
 * */
void Timer(int m) {

	// implement your functionality here
	c1.set_ball( );
	c1.Brick_To_Ball();
	c1.collision();
	c1.setPowersCordinates();
	c1.setTimer(0.1);
	c1.setPaddle1Color();
	c1.setPaddle2Color();
	c1.setLives();
	//c1.checkLevel();


	// once again we tell the library to call our Timer function after next 1000/FPS
	//glutPostRedisplay();
	glutTimerFunc(10.0, Timer, 0);
	
}

/*This function is called (automatically) whenever your mouse moves witin inside the game window
 *
 * You will have to add the necessary code here for finding the direction of shooting
 *
 * This function has two arguments: x & y that tells the coordinate of current position of move mouse
 *
 * */
void MousePressedAndMoved(int x , int y) {
	//cout << x << " " << y << endl;
	//c1.set_mouse_x(x);
	glutPostRedisplay();
}


/*This function is called (automatically) whenever your mouse button is clicked witin inside the game window
 *
 * You will have to add the necessary code here for shooting, etc.
 *
 * This function has four arguments: button (Left, Middle or Right), state (button is pressed or released),
 * x & y that tells the coordinate of current position of move mouse
 *
 * */
void MouseClicked(int button, int state, int x, int y) {

	if (button == GLUT_LEFT_BUTTON) // dealing only with left button
			{
		cout << GLUT_DOWN << " " << GLUT_UP << endl;

	} else if (button == GLUT_RIGHT_BUTTON) // dealing with right button
			{
			cout<<"Right Button Pressed"<<endl;

	}
	glutPostRedisplay();
}
/*
 * our gateway main function
 * */
int main(int argc, char*argv[]) {
	int width = 1000, height = 840; // i have set my window size to be 800 x 600
		c1.level1();
	InitRandomizer(); // seed the random number generator...
	glutInit(&argc, argv); // initialize the graphics library...
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA); // we will be using color display mode
	glutInitWindowPosition(50, 50); // set the initial position of our window
	glutInitWindowSize(width, height); // set the size of our window
	glutCreateWindow("OOP Project"); // set the title of our game window
	SetCanvasSize(width, height); // set the number of pixels...

	// Register your functions to the library,
	// you are telling the library names of function to call for different tasks.
	//glutDisplayFunc(display); // tell library which function to call for drawing Canvas.

	glutDisplayFunc(GameDisplay); // tell library which function to call for drawing Canvas.
	glutSpecialFunc(NonPrintableKeys); // tell library which function to call for non-printable ASCII characters
	glutKeyboardFunc(PrintableKeys); // tell library which function to call for printable ASCII characters
	// This function tells the library to call our Timer function after 1000.0/FPS milliseconds...
	glutTimerFunc(1000.0, Timer, 0);

	glutMouseFunc(MouseClicked);
	glutPassiveMotionFunc(MouseMoved); // Mouse
	glutMotionFunc(MousePressedAndMoved); // Mouse
	
	// now handle the control to library and it will call our registered functions when
	// it deems necessary...
	glutMainLoop();
	return 1;
}
#endif /* AsteroidS_CPP_ */
