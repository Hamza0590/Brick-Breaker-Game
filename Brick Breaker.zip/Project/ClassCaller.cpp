/*
 * ClassCaller.cpp
 *
 *  Created on: Apr 30, 2024
 *      Author: hamza
 */

#include "ClassCaller.h"
#include<fstream>
#include <cstring>
#include<iostream>
#include"util.h"
using namespace std;

ClassCaller::ClassCaller():br1() ,power1()
{
	for (int i =0 ; i<6 ;i++)
	{
			brick [i]=new Brick[10];
	}
	Mouse_x=1;
	level=2;
	score=0;
	lives =2;
	highestScore=0;
	Ball_x=0;
	ballColor=5;
	paddle1Color =0;
	paddle2Color =0;
	powerCheck =0;
	numberOfBricks=60;
	ball2Check =0;
	paddle2Check =0;
	paddle2XCordinate=0;
}
ClassCaller::ClassCaller(int x , int sc , int lvl):p1(x) , power1(),b2(Mouse_x , p1.getPaddleY())
{
	Mouse_x=x;
	level=lvl;
	score=sc;
	lives =2;
	highestScore=0;
	Ball_x=0;
	ballColor=5;
	paddle1Color=0;
	paddle2Color =0;
	powerCheck=0;
	numberOfBricks=60;
	ball2Check=0;
	paddle2Check =0;
	paddle2XCordinate=0;
}

ClassCaller :: ~ClassCaller()
{
	for (int i =0 ; i<6 ; i++)
	{
		delete[] brick[i];
	}
	delete[] brick;
}
void ClassCaller :: setLevel( int val=1)
{
	level = val;
}
void ClassCaller :: setPowerCheck(int val)
{
	powerCheck=val;
}
void ClassCaller :: setBall2Check(int val)
{
	ball2Check = val;
}
int ClassCaller :: getLevel()
{
	return level;
}
void ClassCaller :: setPaddle2Color()
{
	if(((b1.get_ballx()>=p2.getPaddleX()-power1.getPaddleChange()/2) && b1.get_ballx()<=p2.getPaddleX()+105+power1.getPaddleChange()/2) && (b1.get_bally()>=700 && b1.get_bally()<=710))
		paddle2Color=ballColor;
}
void ClassCaller:: ballMaker() // calling ball making function in ball class							//Calling Ball function to detect collision.
{
	//b1.set_paddlex(Mouse_x);
	b1.makeBall(200 , 200);
	b2.makeBall(200 , 200);
}

void ClassCaller :: setPaddle1Color()																			//Setting Paddle1 Color
{
	if ((b1.get_ballx()>=p1.getPaddleX()-power1.getPaddleChange()/2 && b1.get_ballx()<=p1.getPaddleX()+105+power1.getPaddleChange()/2 && (b1.get_bally()>=110 && b1.get_bally()<=120)))
		paddle1Color = ballColor;
}
void ClassCaller:: set_mouse_x(int value)																//Sending Mouse X-Cordinate to Paddle Class
{
	Mouse_x=value;
	p1.setPaddleX(Mouse_x);
	//p2.setPaddleX(paddle2XCordinate);
}
void ClassCaller:: setBallColor(int col)																			//Setting ball Color
{
	ballColor= col;
}

void ClassCaller :: setTimer(double val)																		//Setting Timer again to Zero
{
	power1.setTimer(val);
}
void ClassCaller :: startTimer_Ball()															//sending Hint to Ball class to increase or decrease speed of ball
{

	b1.getStartTimer(power1.getStartTimer());
}
void ClassCaller:: Brick_To_Ball()														//sending 2D Array of Brick to Ball Class for Purpose of Collision detection with Bricks
{
	b1.recieveBrick(brick);
	if(ball2Check==1)
	{
		b2.recieveBrick(brick);
	}
}
void ClassCaller :: setLives()																							//Setting Lives
{
	if(b1.getLiveCheck()==1)
	{
		b1.setLiveCheck();
		lives-=1;

	}
	if(b2.getLiveCheck()==1 && ball2Check==1)
	{
		ball2Check=0;
		b2.setLiveCheck();
		lives-=1;

	}
}
void ClassCaller:: copyPaddlex_ball()																//Copying Paddle X-Cordinate to ball class for Detecting Collision
{
	if (level==3)
	{
		b1.setPaddle1x(Mouse_x);
		b1.setPaddle2x(paddle2XCordinate);
	}
	else
	{
		b1.setPaddle1x(Mouse_x);
	}
	if(ball2Check==1)
	{
		if(level==3)
		{
			b1.setPaddle1x(Mouse_x);
			b1.setPaddle2x(paddle2XCordinate);
			b2.setPaddle1x(Mouse_x);
			b2.setPaddle2x(paddle2XCordinate);
		}
		else
		{
			b1.setPaddle1x(Mouse_x);
			b2.setPaddle1x(Mouse_x);
		}
		//b1.setPaddle1x(Mouse_x);
		//b2.setPaddle2x(paddle2XCordinate);
	}
}
void ClassCaller:: set_ball()																						//Setting Coordinates for Balls
{
	if (level==3)
	{
		b1.setPaddle1x(Mouse_x);
		b1.setPaddle2x(paddle2XCordinate);
	}
	else
	{
		b1.setPaddle1x(Mouse_x);
	}
	if(ball2Check==1)
	{
		if(level==3)
		{
			b1.setPaddle1x(Mouse_x);
			b1.setPaddle2x(paddle2XCordinate);
			b2.setPaddle1x(Mouse_x);
			b2.setPaddle2x(paddle2XCordinate);
		}
		else
		{
			b1.setPaddle1x(Mouse_x);
			b2.setPaddle1x(Mouse_x);
		}
		b2.makeBall(200 , 200);
	}
	b1.makeBall(200 , 200);


}
void ClassCaller:: setHighestScore()																				//Highest Score through File Handling
{
	int score1=0 , score2=0;
	bool check= 1;
		ifstream in;
		in.open("Score.txt");
		while(in>>score1)
		{
			if (score1==score)
			{
				check = 0;
				break;
			}
		}
		in.close();
			ofstream out;
			out.open("Score.txt" , ios:: out | ios::app);
			{
				if (check)
				out<<score<<endl;
			}
			out.close();
	ifstream in2;
	in2.open("Score.txt" , ios::in);
	while(in2>>score1>>score2)
	{
		if (score1>score2)
			highestScore=score1;
		else
			highestScore=score2;

	}
	in2.close();
}

void ClassCaller :: level1() 																					//Levels Pattern of bricks
{
	srand(time(0));
	int tempx=0 , tempy=695;
	if (level==1)
	{

		for (int i=0 ; i<6 ; i++)
		{
			for (int j=0 ; j<10 ; j++ )
			{
				brick[i][j].setColor(rand()%5+1);
				brick[i][j].setBrickY(tempy);
				brick[i][j].setBrickX(tempx);
				brick[i][j].setLength(br1.getLength());
				brick[i][j].setWidth(br1.getWidth());
				tempx+=100;
			}
			tempx=0;
			tempy-=26;
		}
	}
	else if (level==2)
	{
		int count=9;
		for (int i = 0; i < 6; i++ , count--)
		{
		    for (int j = 0; j < 10; j++)
		    {
		        if (i == j || j == count)
		        {
		            brick[i][j].setColor(rand()%5+1);
		            brick[i][j].setBrickY(tempy);
		            brick[i][j].setBrickX(tempx);
		            brick[i][j].setLength(br1.getLength());
		            brick[i][j].setWidth(br1.getWidth());
		        }
		            tempx += 100;
		    }

		    tempx = 0;
		    tempy -= 26;
		}

	}
	else if (level==3)
	{
		paddle2Check=1;
		p2.setPaddleX(450);
		p2.setPaddleY(700);
		tempx=250;
		tempy=550;
		b1.set_bally(150);
		int i=3 , j =0 , indexI=0 , indexJ=0;
		pattern3(i , j , indexI ,indexJ , tempx , tempy);
	}

}
void ClassCaller :: pattern3(int i , int j , int &indexI ,int &indexJ , int &tempx , int &tempy)
{
	if(i==0)
		return;
	else
	{
		if (i==3)
		{
			printPattern3(i-1  ,indexI, indexJ ,tempx , tempy);
		}
		else
		{
			printPattern3(i , indexI , indexJ ,tempx , tempy);
		}
		tempx+=(j*100);
		printPattern3(i ,indexI , indexJ  ,tempx , tempy);
		tempy-=25 , tempx=250 , indexJ=0;
		if(j==0)
		{
			indexI+=1;
			pattern3(i-1 ,j+1 ,indexI  , indexJ , tempx , tempy);
		}
		else
		{
			indexI+=1;
			pattern3(i-1 , j+2 , indexI , indexJ , tempx , tempy);
		}


			if(i==1)
			{
				tempy+=25;
				indexI-=1;
			}
			tempy-=25 , tempx=250 , indexJ=0 , indexI+=1;
			if(i==3)
			{
				printPattern3(i-1 , indexI , indexJ , tempx , tempy);
			}
			else
			{
				printPattern3( i , indexI ,indexJ , tempx , tempy);
			}
			tempx+=(j*100);
			printPattern3(i ,indexI , indexJ  ,tempx , tempy);
			//tempy-=25;



	}
}
void ClassCaller :: printPattern3(int i ,int &indexI , int &indexJ ,  int &tempx , int &tempy)
{
	if(i==0)
		return ;
	else
	{
		brick[indexI][indexJ].setColor(rand()%5+1);
		brick[indexI][indexJ].setBrickY(tempy);
		brick[indexI][indexJ].setBrickX(tempx);
		brick[indexI][indexJ].setLength(br1.getLength());
		brick[indexI][indexJ].setWidth(br1.getWidth());
		tempx+=100;
		indexJ+=1;
		printPattern3(i-1 , indexI ,indexJ  , tempx , tempy);
	}
}

void ClassCaller::collision() 																			//Detecting Collision with ball and setting color of ball
{
	for (int i = 5; i >= 0; i--)
	{
	    for (int j = 0; j < 10; j++)
	    {

	        if ((b1.get_ballx() >= brick[i][j].getBrickX() && b1.get_ballx() <= brick[i][j].getBrickX() + 100) &&
	            (b1.get_bally() >= brick[i][j].getBrickY() && b1.get_bally() <= brick[i][j].getBrickY()+25) ||
				(b2.get_ballx() >= brick[i][j].getBrickX() && b2.get_ballx() <= brick[i][j].getBrickX() + 100) &&
			    (b2.get_bally() >= brick[i][j].getBrickY() && b2.get_bally() <= brick[i][j].getBrickY()+25))
	        {
	        	if(brick[i][j].getColor()==1)
	        	{
	        		ballColor=1;
	        	}
	        	else if(brick[i][j].getColor()==2)
	        	{
                  	ballColor=2;
	        	}
	        	else if(brick[i][j].getColor()==3)
	        	{
                  	ballColor=3;
	        	}
	        	else if(brick[i][j].getColor()==4)
	        	{
                  	ballColor=4;
	        	}
	        	else if(brick[i][j].getColor()==5)
	        	{
                  	ballColor=5;
	        	}
	        	b1.makeBall(i , j);
	        	if(ball2Check==1)
	        	{
	        		b2.makeBall(i , j);
	        	}
	        	int temp=0;
	        	temp= brick[i][j].getBrickCount()+1;
	            brick[i][j].setBrickCount(temp);
	            if (brick[i][j].getColor() == 1 || brick[i][j].getColor() == 5) // Red  and Blue
	            {

	                if (brick[i][j].getBrickCount() == 3)//3
	                {
	                	if(brick[i][j].getColor()==1)
						{
							power1.setPowerColor(1);
						}
						else if(brick[i][j].getColor()==5)
						{
							power1.setPowerColor(5);
						}
	                	powerCheck =1;
	                	power1.setPowerX(brick[i][j].getBrickX()+10);
	                	power1.setPowerY(brick[i][j].getBrickY());
	                	brick[i][j].setColor(0);
	                    brick[i][j].setBrickX(2000);
	                    brick[i][j].setBrickY(2000);
	                    score+=5;
	                    numberOfBricks--;
	                }
	            }
	            else if (brick[i][j].getColor() == 2 || brick[i][j].getColor() == 3) // Pink and Yellow
	            {
	                if (brick[i][j].getBrickCount()== 2)//2
	                {
	                	if(brick[i][j].getColor()==2)
						{
							power1.setPowerColor(2);
						}
						else if(brick[i][j].getColor()==3)
						{
							power1.setPowerColor(3);
						}
	                	powerCheck =1;
						power1.setPowerX(brick[i][j].getBrickX()+10);
						power1.setPowerY(brick[i][j].getBrickY());
	                    brick[i][j].setBrickX(2000);
	                    brick[i][j].setBrickY(2000);
	                    brick[i][j].setColor(0);
	                    score+=5;
	                    numberOfBricks--;
	                }
	            }
	            else if (brick[i][j].getColor() == 4) //green
	            {
	                if (brick[i][j].getBrickCount() == 1)
	                {
	                	power1.setPowerColor(4);
	                	powerCheck =1;
						power1.setPowerX(brick[i][j].getBrickX()+10);
						power1.setPowerY(brick[i][j].getBrickY());
	                    brick[i][j].setBrickX(2000);
	                    brick[i][j].setBrickY(2000);
	                    brick[i][j].setColor(0);
	                    numberOfBricks--;
	                    score+=5;
	                }
	            }
	        }
	    }
	}
}

void ClassCaller :: setPowersCordinates()
{
	if (power1.getPowerY()>=110 && power1.getPowerY()<=120 &&
			(power1.getPowerX()>=(p1.getPaddleX()-power1.getPaddleChange()/2) && power1.getPowerX()<=(p1.getPaddleX()+100+power1.getPaddleChange())))
	{
		int val =0;
		powerCheck =0;
		power1.setPowerY(2000);
		power1.setPowerX(2000);
		setStartTimer();
		setTimer(0.001);
		if (power1.getPowerColor()==4 )
		{
			val = 100;
			b1.setPaddleChange(val);
			if(ball2Check==1)
			{
				b2.setPaddleChange(val);
			}
			power1.setPaddleChange(val);
		}
		else if (power1.getPowerColor()==3)
		{
			val=0;
			b1.setPaddleChange(val);
			if(ball2Check==1)
			{
				b2.setPaddleChange(val);
			}
			power1.setPaddleChange(val);
		}
		else if (power1.getPowerColor()==2)
		{
			power1.setStartTimer(1);
			ball2Check=1;
		}
		else if (power1.getPowerColor()==1)
		{
			power1.setStartTimer(1);
			b1.getStartTimer(2);
			if(ball2Check==1)
			{
				b2.getStartTimer(2);
			}
		}
		else if (power1.getPowerColor()==5)
		{
			power1.setStartTimer(1);
			b1.getStartTimer(5);
			if(ball2Check==1)
			{
				b2.getStartTimer(5);
			}
		}
		power1.setPowerColor(0);
	}
	else
	{
		int temp = power1.getPowerY();
			temp-=3;
			power1.setPowerY(temp);
	}

}

int ClassCaller :: getPowerCheck()
{
	return powerCheck;
}

int ClassCaller:: getHighestScore()
{
	return highestScore;
}

int ClassCaller :: getLives()
{
	return lives;
}

int ClassCaller:: getScore()
{
	return score;
}

int ClassCaller:: get_ball()
{
	return Ball_x;
}

int ClassCaller:: get_mouse_x()
{
	return Mouse_x;
}

int ClassCaller:: getBallColor() // returning ball color
{
	return ballColor;
}

int ClassCaller :: getPaddle1Color()
{
	return paddle1Color;
}

int ClassCaller :: getPaddle2Color()
{
	return paddle2Color;
}
Paddle ClassCaller:: returnPaddle() // returning class paddle object
{
	return p1;
}
Ball ClassCaller:: returnBall() //returning class ball object
{
	return b1;
}

Brick **ClassCaller:: returnBrickArray() //return 2D-Array of brick
{
	return brick;
}


Ball ClassCaller:: getBall2()
{
	return b2;
}

int ClassCaller :: getBall2Check()
{
	return ball2Check;
}
Powers ClassCaller:: getPower1()
{
	return power1;
}
void ClassCaller :: setStartTimer()
{
	power1.setStartTimer(0);
	ball2Check =0;
	b1.getStartTimer(0);
}

void ClassCaller :: setPaddle2XCordinate(int val)
{
	paddle2XCordinate=val;
	if(paddle2XCordinate+p2.getPaddleX()>=0+power1.getPaddleChange()/2 && paddle2XCordinate+p2.getPaddleX()<=900-power1.getPaddleChange()/2) // if paddle cordinates are with in the frame then assigning value
	{
		p2.setPaddleX(p2.getPaddleX()+val);
		val+=p2.getPaddleX();
		b2.setPaddle2x(val);
	}
}

void ClassCaller :: checkLevel()
{
	if (level==1)
	{
		if (numberOfBricks==0)
		{
			for (int i =0  ; i<6 ; i++)
			{
				for (int j =0 ; j<10 ; j++)
				{
					brick[i][j].setBrickCount(0);
					brick[i][j].setBrickX(2000);
					brick[i][j].setBrickY(2000);
				}
			}
			numberOfBricks = 12;
			lives=2;
			level=2;
			b1.set_ballx(500);
			b1.set_bally(410);
			level1();
		}
	}
	else if (level==2 )
	{
		if (numberOfBricks==0)
		{
			for (int i =0  ; i<6 ; i++)
			{
				for (int j =0 ; j<10 ; j++)
				{
					brick[i][j].setBrickCount(0);
					brick[i][j].setBrickX(2000);
					brick[i][j].setBrickY(2000);
				}
			}
			numberOfBricks = 22;
			lives=2;
			level=3;
			level1();
		}
	}
	else if (level==3)
	{
		if (numberOfBricks==0)
		{
			for (int i =0  ; i<6 ; i++)
			{
				for (int j =0 ; j<10 ; j++)
				{
					brick[i][j].setBrickCount(0);
					brick[i][j].setBrickX(2000);
					brick[i][j].setBrickY(2000);
				}
			}

			lives=0;
		}
	}
}
void ClassCaller :: setPaddle2Check(int val)
{
	paddle2Check = val;
}
Paddle ClassCaller:: getPaddle2()
{
	return p2;
}
int ClassCaller :: getPaddle2Check()
{
	return paddle2Check;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
											//Powers
Powers:: Powers()
{
	powerX=2000;
	powerY=2000;
	powerColor=0;
	paddleChange=0;
	timer = 0.001;
}
void Powers :: setPaddleChange( int val)
{
	paddleChange=val;
}
int Powers:: getPaddleChange()
{
	return paddleChange;
}

void Powers :: setPowerX(int val)
{
	powerX=val;
}
void Powers:: setPowerY(int val)
{
	powerY=val;
}
void Powers:: setPowerColor(int val)
{
	powerColor= val;
}
int Powers:: getPowerX()
{
	return powerX;
}
int Powers:: getPowerY()
{
	return powerY;
}
int Powers:: getPowerColor()
{
	return powerColor;
}
void Powers :: setStartTimer(double val)
{
	startTimer = val;
}
int Powers :: getStartTimer()
{
	return startTimer;
}
void Powers:: setTimer(double val)
{
	if (startTimer==1)
	timer+=val;
	else if (val==0.001)
		timer=0.001;
}
double Powers:: getTimer()
{
	return timer;
}



////////////////////////////////////////////////////////////////////////////////////////////////////////
											//Brick
Brick :: Brick()
{
	x=2000;
	y=2000;
	length=100;
	width=25;
	color=1;
	count=0;
}
Brick :: Brick (int leng, int wid, int x_cor,int y_cor, int col)
{
	length=leng;
	width = wid;
	color=col;
	x=x_cor;
	y=y_cor;
	count=0;
}
void Brick :: setColor(int clr)
{
	color = clr;
}
void Brick :: setLength(int leng)
{
	length=leng;
}
void Brick :: setWidth(int w)
{
	width = w;
}
void Brick :: setBrickX(int x_cor)
{
	x=x_cor;
}
void Brick :: setBrickY(int y_cor)
{
	y=y_cor;
}
int Brick :: getColor()
{
	return color;
}
void Brick :: setBrickCount(int value)
{
	count=value;
}
int Brick :: getBrickCount()
{
	return count;
}
int Brick :: getLength()
{
	return length;
}
int Brick :: getWidth()
{
	return width;
}
int Brick :: getBrickX()
{
	return x;
}
int Brick :: getBrickY()
{
	return y;
}





////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
											 //Ball
Ball:: Ball()
{
	check2=1;
	check1=0 ;
	y=410;
	x=500;
	liveCheck=0;
	paddleChangeCopy=0;
	speedUpDown=0;
}
Ball:: Ball(int set_x , int set_y)
{
	x=set_x;
	y=set_y;
	check2=1;
	check1=0;
	liveCheck=0;
	paddleChangeCopy=0;
	speedUpDown=0;
}
void Ball :: setPaddle1x(int value )
{
	paddle1x=value;
}
void Ball :: setPaddle2x(int val )
{
	paddle2x=val;
}
void Ball:: set_ballx(int value)
{
	x=value;

}
void Ball:: set_bally(int value)
{
	y=value;
}
int Ball:: get_ballx()
{
	return x;
}
int Ball:: get_bally()
{
	return y;
}
int Ball::getLiveCheck()
{
	return liveCheck;
}
void Ball:: setLiveCheck()
{
	liveCheck =0;
}
void Ball:: recieveBrick(Brick** copy)
{
	ballBrick=copy;
}
void Ball :: setPaddleChange(int val)
{
	paddleChangeCopy=val;
}
void Ball:: getStartTimer(int  val )
{
	if (val==0)
		speedUpDown=0;
	else if (val==5)
		speedUpDown =-4;
	else
		speedUpDown = 4;
}

void Ball::makeBall(int dummyI , int dummyJ)
{
	if (dummyI==200 && dummyJ==200)
	{
		if (x<=0 || x >= 1000)
		{
			check1 = !check1;
		}
		if ((((y>=110) && (y<=120))&& (((x+5)>=paddle1x-paddleChangeCopy/2) && (x+5)<=paddle1x+105+paddleChangeCopy/2+speedUpDown))||
				(((y>=700) && (y<=710))&& (((x+5)>=paddle2x-paddleChangeCopy/2) && (x+5)<=paddle2x+105+paddleChangeCopy/2+speedUpDown))|| y >= 720 || y<=0)
		{
			   check2 = !check2;
		}
		if(check1)
		{
			x = x+5+speedUpDown;
		}
		else
		{
			x =x-5-speedUpDown;
		}
		if(check2)
		{
			y =y+5+speedUpDown;
		}
		else
		{
			y =y-5-speedUpDown;
		}
		if (y<=0)
		{
			x=500;
			y=410;
			liveCheck=1;
			check2=!check2;
		}
	}
	else
	{

		if (y>=ballBrick[dummyI][dummyJ].getBrickY() && y<=ballBrick[dummyI][dummyJ].getBrickY()+26)
			check2=!check2;
		if (x<=ballBrick[dummyI][dummyJ].getBrickX() && x>=ballBrick[dummyI][dummyJ].getBrickX()-100)
		{
			if(check2)
				check1=!check1;
		}
		if(check1)
		{
			x += 5;
		}
		else
		{
			x -= 5;
		}
		if(check2)
		{
			y += 5;
		}
		else
		{
			y -= 5;
		}
	}
    glutPostRedisplay();
}





////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
													//Paddle
Paddle::Paddle()
{
	x=200;
	y =100;
}
Paddle::Paddle(int mouse_x )
{
	x=mouse_x;
	y=100;
}
void Paddle :: setPaddleY(int y_val)
{
	y=y_val;
}
void Paddle:: setPaddleX(int x_val)
{
	x=x_val;
}
int Paddle:: getPaddleX()
{
	return x;
}
int Paddle:: getPaddleY()
{
	return y;
}



