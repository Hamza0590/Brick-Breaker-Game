/*
 * ClassCaller.h
 *
 *  Created on: Apr 30, 2024
 *      Author: hamza
 */

#ifndef CLASSCALLER_H_
#define CLASSCALLER_H_
#include<ctime>

class Powers
{
	int powerX , powerY , powerColor , paddleChange , startTimer;
	double timer;
public:
	Powers();
	void setPowerX(int);
	void setPowerY(int);
	void setPowerColor(int);
	void setPaddleChange(int );
	int getPaddleChange();
	int getPowerX();
	int getPowerY();
	int getPowerColor();
	void setTimer(double);
	double getTimer();
	int getStartTimer();
	void setStartTimer(double);
};

class Brick
{
	int color , length , width , x , y , count;

public:
		Brick();
		Brick(int , int , int ,int , int);
		void setColor(int);
		void setLength(int);
		void setWidth(int);
		void setBrickX(int);
		void setBrickY(int);
		void setBrickCount(int);
		int getBrickCount();
		int getColor();
		int getLength();
		int getWidth();
		int getBrickX();
		int getBrickY();

};


class Ball
{
	int check1 , check2;
	int x;
	int y;
	int paddle1x , paddle2x , paddleLength;
	Brick **ballBrick;
	int ballColor;
	int liveCheck;
	int paddleColor;
	int paddleChangeCopy;
	int speedUpDown;
public:
		Ball();
		Ball(int , int);
		int get_copyPaddlex();
		void set_ballx(int);
		void set_paddleLength(int);
		void set_bally(int);
		void makeBall(int , int);
		int get_ballx();
		int get_bally();
		int getLiveCheck();
		void setLiveCheck();
		void setPaddle1x(int);
		void setPaddle2x(int);
		void setPaddleChange(int);
		void recieveBrick(Brick **);
		void getStartTimer(int);

};

class Paddle
{
	int x , y;
public:
	Paddle();
	Paddle(int);
	void setPaddleX(int);
	void setPaddleY(int);
	int getPaddleLength();
	int getPaddleX();
	int getPaddleY();

};



class ClassCaller {
	int level;
	int Mouse_x;
	int Ball_x;
	Paddle p1;
	Paddle p2;
	int paddle2Check;
	int paddle2XCordinate;
	Ball b1;
	Ball b2;
	int ball2Check;
	Brick br1;
	Brick **brick = new Brick *[6];
	int score;
	int highestScore;
	int lives;
	int ballColor;
	int paddle1Color;
	int paddle2Color;
	int powerCheck;
	Powers power1;
	int numberOfBricks;
public:
		ClassCaller();
		ClassCaller(int ,int , int );
		~ClassCaller();
		int getLives();
		void setLives();
		int getScore();
		void copyPaddlex_ball();
		int get_mouse_x();
		void set_mouse_x(int);
		int get_ball();
		void set_ball();
		Paddle returnPaddle();
		Ball returnBall();
		void paddleMaker();
		void ballMaker();
		void level1();
		void level2();
		void collision();
		Brick** returnBrickArray();
		void  Brick_To_Ball();
		void setHighestScore();
		int getHighestScore();
		void copyPaddley_ball();
		void setBallColor(int);
		int getBallColor();
		void setPaddle1Color();
		int getPaddle1Color();
		void setPaddle2Color();
		int getPaddle2Color();
		void setPowerCheck(int);
		int getPowerCheck();
		void setPowersCordinates();
		Powers getPower1();
		void setLevel(int);
		int getLevel();
		void setStartTimer();
		void setTimer(double);
		void startTimer_Ball();
		void checkLevel();
		void setPaddle2Check(int);
		int getPaddle2Check();
		Paddle getPaddle2();
		void setPaddle2XCordinate(int);
		int getPaddle2XCordinate();
		void setBall2Check(int);
		int getBall2Check();
		Ball getBall2();
		void pattern3(int, int , int &, int& , int &, int&  );
		void printPattern3(int , int &, int& , int  &,int&);

};



#endif /* CLASSCALLER_H_ */
